Team Members:
[Betty Nguyen], [A01028857], [1B], [May 6th, 2022]
[Maxwell Babey], [A01271687], [2C], [May 6th, 2022]
[Kyle Ng], [A01017006], [2A], [May 6th, 2022]
[Caroline Lin], [A0120627], [1B], [May 6th, 2022]
This assignment is [100]% complete.
[explanation if not complete, what is working/not
working]